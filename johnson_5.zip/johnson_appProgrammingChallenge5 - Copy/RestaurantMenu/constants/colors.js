const Colors = {
  accentColor: "#FF9E0E",
  menuRed: '#990D04',
  menuAccentRed: '#700004'
}
export default Colors;